
import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useWeather } from '@/contexts/WeatherContext';
import WeatherChart from '@/components/WeatherChart';
import { getWeatherIcon, getUvSeverity } from '@/components/Icons';
import LoadingSpinner from '@/components/LoadingSpinner';
import Navigation from '@/components/Navigation';

const WeeklyReport: React.FC = () => {
  const { weatherData, isLoading } = useWeather();

  if (isLoading) {
    return (
      <div className="app-container flex flex-col justify-center items-center">
        <LoadingSpinner size="large" />
        <p className="mt-4 text-white">Loading weather data...</p>
      </div>
    );
  }

  if (!weatherData) {
    return (
      <div className="app-container flex flex-col justify-center items-center">
        <p className="text-white">No weather data available</p>
      </div>
    );
  }

  // Generate temperature data for chart
  const tempData = weatherData.dailyForecast.slice(0, 7).map(day => ({
    name: day.day,
    value: day.temperature.high,
    low: day.temperature.low
  }));

  // Generate precipitation data for chart
  const precipData = weatherData.dailyForecast.slice(0, 7).map(day => ({
    name: day.day,
    value: day.precipitation
  }));

  // Generate UV index data for chart
  const uvData = weatherData.dailyForecast.slice(0, 7).map(day => ({
    name: day.day,
    value: day.uvIndex
  }));

  // Generate wind data for chart
  const windData = weatherData.dailyForecast.slice(0, 7).map(day => ({
    name: day.day,
    value: day.wind
  }));

  // Calculate averages
  const avgTemp = Math.round(tempData.reduce((acc, day) => acc + day.value, 0) / tempData.length);
  const avgPrecip = Math.round(precipData.reduce((acc, day) => acc + day.value, 0) / precipData.length);
  const avgUV = Math.round(uvData.reduce((acc, day) => acc + day.value, 0) / uvData.length);
  const avgWind = Math.round(windData.reduce((acc, day) => acc + day.value, 0) / windData.length);
  
  // Get UV severity
  const uvSeverity = getUvSeverity(avgUV);

  return (
    <div className="app-container">
      <div className="page-container pb-6">
        <div className="mb-6">
          <Link to="/reports" className="flex items-center text-white">
            <ChevronLeft size={20} />
            <span className="ml-1">Back to Reports</span>
          </Link>
        </div>
        
        <h1 className="text-2xl font-bold text-white mb-6">Weekly Weather Report</h1>
        
        <div className="grid gap-4 mb-8 animate-fade-in">
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle>7-Day Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col items-center p-4 rounded-lg bg-gray-50">
                  <span className="text-sm text-gray-500">Avg Temperature</span>
                  <span className="text-3xl font-bold text-majira-blue mt-1">{avgTemp}°C</span>
                </div>
                <div className="flex flex-col items-center p-4 rounded-lg bg-gray-50">
                  <span className="text-sm text-gray-500">Avg Precipitation</span>
                  <span className="text-3xl font-bold text-majira-blue mt-1">{avgPrecip}%</span>
                </div>
                <div className="flex flex-col items-center p-4 rounded-lg bg-gray-50">
                  <span className="text-sm text-gray-500">Avg UV Index</span>
                  <span className={`text-3xl font-bold mt-1 ${uvSeverity.color}`}>{avgUV}</span>
                </div>
                <div className="flex flex-col items-center p-4 rounded-lg bg-gray-50">
                  <span className="text-sm text-gray-500">Avg Wind Speed</span>
                  <span className="text-3xl font-bold text-majira-blue mt-1">{avgWind} km/h</span>
                </div>
              </div>
              
              <div className="mt-6 border-t pt-4">
                <h3 className="font-medium mb-2">Weekly Conditions</h3>
                <div className="flex justify-between">
                  {weatherData.dailyForecast.slice(0, 7).map((day, idx) => (
                    <div key={idx} className="flex flex-col items-center">
                      <span className="text-xs text-gray-500">{day.day}</span>
                      <div className="my-1 text-majira-blue">
                        {getWeatherIcon(day.condition, { size: 24 })}
                      </div>
                      <span className="text-xs font-medium">{day.temperature.high}°</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="space-y-6 animate-fade-in" style={{ animationDelay: '0.1s' }}>
          <Card>
            <CardHeader>
              <CardTitle>Temperature (°C)</CardTitle>
            </CardHeader>
            <CardContent>
              <WeatherChart 
                data={tempData} 
                dataKey="value" 
                label="Temperature" 
                unit="°C"
                color="#1E88E5"
              />
              <div className="mt-4 text-sm">
                <p className="text-gray-600">
                  <span className="font-medium">Analysis:</span> Temperatures will {avgTemp > 30 ? 'remain high' : avgTemp > 25 ? 'be moderate' : 'be relatively cool'} throughout the week 
                  with an average high of {avgTemp}°C.
                </p>
                <p className="text-gray-600 mt-2">
                  <span className="font-medium">Agricultural Impact:</span> {avgTemp > 30 
                    ? 'High temperatures may stress crops. Ensure adequate irrigation.' 
                    : avgTemp > 25 
                      ? 'Favorable temperatures for most crops. Maintain regular care.' 
                      : 'Cooler temperatures may slow growth. Monitor sensitive crops.'}
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Precipitation (%)</CardTitle>
            </CardHeader>
            <CardContent>
              <WeatherChart 
                data={precipData} 
                dataKey="value" 
                label="Precipitation" 
                unit="%"
                color="#42A5F5"
              />
              <div className="mt-4 text-sm">
                <p className="text-gray-600">
                  <span className="font-medium">Analysis:</span> {avgPrecip > 70 
                    ? 'Heavy rainfall expected throughout the week.' 
                    : avgPrecip > 40 
                      ? 'Moderate precipitation expected on several days.' 
                      : 'Minimal rainfall expected this week.'}
                </p>
                <p className="text-gray-600 mt-2">
                  <span className="font-medium">Agricultural Impact:</span> {avgPrecip > 70 
                    ? 'Risk of waterlogging. Ensure proper drainage systems are functioning.' 
                    : avgPrecip > 40 
                      ? 'Good conditions for crop growth. Reduce irrigation on rainy days.' 
                      : 'Dry conditions. Maintain regular irrigation schedule.'}
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>UV Index</CardTitle>
            </CardHeader>
            <CardContent>
              <WeatherChart 
                data={uvData} 
                dataKey="value" 
                label="UV Index" 
                unit=""
                color="#FB8C00"
              />
              <div className="mt-4 text-sm">
                <p className="text-gray-600">
                  <span className="font-medium">Analysis:</span> Weekly average UV index is{' '}
                  <span className={uvSeverity.color}>
                    {uvSeverity.level} ({avgUV})
                  </span>.
                </p>
                <p className="text-gray-600 mt-2">
                  <span className="font-medium">Agricultural Impact:</span> {uvSeverity.level === 'Extreme' || uvSeverity.level === 'Very High'
                    ? 'High risk for workers and sensitive crops. Limit midday field activities and consider shade structures for sensitive plants.'
                    : uvSeverity.level === 'High'
                      ? 'Moderate risk. Workers should wear protective clothing and take regular breaks in shaded areas.'
                      : 'Low to moderate UV levels. Standard precautions advised.'}
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Wind Speed (km/h)</CardTitle>
            </CardHeader>
            <CardContent>
              <WeatherChart 
                data={windData} 
                dataKey="value" 
                label="Wind Speed" 
                unit="km/h"
                color="#26A69A"
              />
              <div className="mt-4 text-sm">
                <p className="text-gray-600">
                  <span className="font-medium">Analysis:</span> {avgWind > 20 
                    ? 'Strong winds expected throughout the week.' 
                    : avgWind > 10 
                      ? 'Moderate breeze expected on most days.' 
                      : 'Gentle winds expected throughout the week.'}
                </p>
                <p className="text-gray-600 mt-2">
                  <span className="font-medium">Agricultural Impact:</span> {avgWind > 20 
                    ? 'High wind may damage crops. Consider windbreaks and supporting tall plants.' 
                    : avgWind > 10 
                      ? 'Moderate wind provides good air circulation but monitor water evaporation rates.' 
                      : 'Light wind conditions. Watch for humidity-related issues in dense crop areas.'}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <Navigation />
    </div>
  );
};

export default WeeklyReport;
