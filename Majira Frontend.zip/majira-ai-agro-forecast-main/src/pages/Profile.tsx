
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Edit2, Save, LogOut } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import LoadingSpinner from '@/components/LoadingSpinner';
import Navigation from '@/components/Navigation';

const Profile: React.FC = () => {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    region: user?.region || '',
    avatar: user?.avatar || ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleSave = () => {
    setIsSaving(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      setIsEditing(false);
      
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully."
      });
    }, 1000);
  };

  const handleLogout = () => {
    logout();
    
    toast({
      title: "Logged out",
      description: "You have been logged out successfully."
    });
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };

  return (
    <div className="app-container">
      <div className="page-container pb-6">
        <h1 className="text-2xl font-bold text-white mb-6">Profile</h1>
        
        <div className="glass-card p-6 mb-6 animate-fade-in">
          <div className="flex flex-col items-center">
            <Avatar className="w-24 h-24 mb-4">
              <AvatarImage src={formData.avatar} alt={formData.name} />
              <AvatarFallback className="text-xl bg-majira-blue text-white">
                {getInitials(formData.name)}
              </AvatarFallback>
            </Avatar>
            
            <h2 className="text-xl font-bold">{formData.name}</h2>
            <p className="text-gray-600">{formData.email}</p>
            
            {!isEditing && (
              <Button 
                variant="outline" 
                className="mt-4 flex items-center" 
                onClick={handleEdit}
              >
                <Edit2 size={16} className="mr-2" />
                Edit Profile
              </Button>
            )}
          </div>
        </div>
        
        <div className="glass-card p-6 mb-6 animate-fade-in" style={{ animationDelay: '0.1s' }}>
          <h2 className="text-lg font-semibold mb-4">Profile Information</h2>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                disabled={!isEditing}
                className={!isEditing ? 'bg-gray-50' : ''}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                disabled={!isEditing}
                className={!isEditing ? 'bg-gray-50' : ''}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="region">Region</Label>
              <Input
                id="region"
                name="region"
                value={formData.region}
                onChange={handleInputChange}
                disabled={!isEditing}
                className={!isEditing ? 'bg-gray-50' : ''}
              />
            </div>
            
            {isEditing && (
              <div className="flex justify-end mt-6">
                <Button 
                  variant="outline" 
                  className="mr-2"
                  onClick={() => setIsEditing(false)}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleSave}
                  disabled={isSaving}
                  className="bg-majira-blue hover:bg-majira-blue-dark"
                >
                  {isSaving ? (
                    <LoadingSpinner size="small" />
                  ) : (
                    <>
                      <Save size={16} className="mr-2" />
                      Save Changes
                    </>
                  )}
                </Button>
              </div>
            )}
          </div>
        </div>
        
        <div className="glass-card p-6 animate-fade-in" style={{ animationDelay: '0.2s' }}>
          <h2 className="text-lg font-semibold mb-4">Account Settings</h2>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b">
              <div>
                <h3 className="font-medium">Notifications</h3>
                <p className="text-sm text-gray-600">Receive weather alerts and updates</p>
              </div>
              <div className="flex items-center">
                <span className="text-xs bg-green-100 text-green-800 py-1 px-2 rounded">Enabled</span>
              </div>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b">
              <div>
                <h3 className="font-medium">Data Usage</h3>
                <p className="text-sm text-gray-600">Optimize for lower data consumption</p>
              </div>
              <div className="flex items-center">
                <span className="text-xs bg-gray-100 text-gray-800 py-1 px-2 rounded">Disabled</span>
              </div>
            </div>
            
            <div className="flex justify-between items-center py-2">
              <div>
                <h3 className="font-medium">Location Access</h3>
                <p className="text-sm text-gray-600">Allow access to your location</p>
              </div>
              <div className="flex items-center">
                <span className="text-xs bg-green-100 text-green-800 py-1 px-2 rounded">Enabled</span>
              </div>
            </div>
          </div>
          
          <div className="mt-8">
            <Button 
              variant="destructive" 
              className="w-full flex items-center justify-center"
              onClick={handleLogout}
            >
              <LogOut size={16} className="mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>
      
      <Navigation />
    </div>
  );
};

export default Profile;
