
import React from 'react';
import { Link } from 'react-router-dom';
import { CloudOff, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';

const NotFound: React.FC = () => {
  return (
    <div className="min-h-screen bg-blue-gradient flex flex-col items-center justify-center px-4 py-12">
      <div className="glass-card p-8 max-w-md w-full text-center animate-fade-in">
        <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-red-100 flex items-center justify-center">
          <CloudOff size={40} className="text-red-500" />
        </div>
        
        <h1 className="text-3xl font-bold mb-2">404</h1>
        <p className="text-xl font-medium mb-4">Page Not Found</p>
        <p className="text-gray-600 mb-8">
          The page you are looking for doesn't exist or has been moved.
        </p>
        
        <Button asChild className="bg-majira-blue hover:bg-majira-blue-dark">
          <Link to="/" className="flex items-center justify-center">
            <Home size={18} className="mr-2" />
            Back to Home
          </Link>
        </Button>
      </div>
    </div>
  );
};

export default NotFound;
