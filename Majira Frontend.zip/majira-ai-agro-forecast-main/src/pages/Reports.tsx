
import React from 'react';
import { Link } from 'react-router-dom';
import { 
  CalendarDays, 
  ArrowRight 
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useWeather } from '@/contexts/WeatherContext';
import WeatherChart from '@/components/WeatherChart';
import { getWeatherIcon } from '@/components/Icons';
import LoadingSpinner from '@/components/LoadingSpinner';
import Navigation from '@/components/Navigation';

const Reports: React.FC = () => {
  const { weatherData, isLoading } = useWeather();

  if (isLoading) {
    return (
      <div className="app-container flex flex-col justify-center items-center">
        <LoadingSpinner size="large" />
        <p className="mt-4 text-white">Loading weather data...</p>
      </div>
    );
  }

  if (!weatherData) {
    return (
      <div className="app-container flex flex-col justify-center items-center">
        <p className="text-white">No weather data available</p>
      </div>
    );
  }

  // Generate temperature data for chart
  const tempData = weatherData.dailyForecast.slice(0, 7).map(day => ({
    name: day.day,
    value: day.temperature.high,
    color: '#1E88E5'
  }));

  // Generate precipitation data for chart
  const precipData = weatherData.dailyForecast.slice(0, 7).map(day => ({
    name: day.day,
    value: day.precipitation,
    color: '#1E88E5'
  }));

  return (
    <div className="app-container">
      <div className="page-container pb-6">
        <h1 className="text-2xl font-bold text-white mb-6">Weather Reports</h1>
        
        <div className="grid gap-4 mb-8 animate-fade-in">
          <Link to="/reports/daily" className="block">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg">Daily Report</CardTitle>
                <ArrowRight size={18} className="text-gray-500" />
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <div className="flex-1">
                    <p className="text-sm text-gray-500">Today</p>
                    <div className="flex items-center mt-1">
                      <p className="text-xl font-semibold mr-2">
                        {weatherData.dailyForecast[0].temperature.high}°C
                      </p>
                      <p className="text-gray-500">
                        {weatherData.dailyForecast[0].temperature.low}°C
                      </p>
                    </div>
                  </div>
                  <div className="text-majira-blue">
                    {getWeatherIcon(weatherData.dailyForecast[0].condition, { size: 40 })}
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
          
          <Link to="/reports/weekly" className="block">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg">Weekly Report</CardTitle>
                <ArrowRight size={18} className="text-gray-500" />
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500">7-Day Forecast</p>
                    <p className="mt-1">
                      <span className="text-xl font-semibold">
                        {Math.round(weatherData.dailyForecast.slice(0, 7).reduce((acc, day) => acc + day.temperature.high, 0) / 7)}°C
                      </span>
                      <span className="text-gray-500 text-sm ml-2">avg high</span>
                    </p>
                  </div>
                  <div className="flex space-x-1">
                    {weatherData.dailyForecast.slice(0, 5).map((day, idx) => (
                      <div key={idx} className="text-majira-blue opacity-80">
                        {getWeatherIcon(day.condition, { size: 16 })}
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
          
          <Link to="/reports/monthly" className="block">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg">Monthly Report</CardTitle>
                <ArrowRight size={18} className="text-gray-500" />
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <div className="flex-1">
                    <p className="text-sm text-gray-500 flex items-center">
                      <CalendarDays size={14} className="mr-1" />
                      Monthly Overview
                    </p>
                    <p className="mt-1">
                      <span className="text-xl font-semibold">{weatherData.monthlyReport.averageTemp}°C</span>
                      <span className="text-gray-500 text-sm ml-2">avg temp</span>
                    </p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Precipitation</p>
                    <p className="text-xl font-semibold text-majira-blue">
                      {weatherData.monthlyReport.totalPrecipitation}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>
        
        <div className="space-y-6 animate-fade-in" style={{ animationDelay: '0.1s' }}>
          <Card>
            <CardHeader>
              <CardTitle>Temperature Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <WeatherChart 
                data={tempData} 
                dataKey="value" 
                label="Temperature" 
                unit="°C"
                color="#1E88E5"
              />
              <div className="mt-4">
                <Button asChild variant="outline" className="w-full">
                  <Link to="/reports/weekly">View Detailed Analysis</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Precipitation Forecast</CardTitle>
            </CardHeader>
            <CardContent>
              <WeatherChart 
                data={precipData} 
                dataKey="value" 
                label="Precipitation" 
                unit="%"
                color="#42A5F5"
              />
              <div className="mt-4">
                <Button asChild className="w-full">
                  <Link to="/reports/weekly">View Full Forecast</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <Navigation />
    </div>
  );
};

export default Reports;
