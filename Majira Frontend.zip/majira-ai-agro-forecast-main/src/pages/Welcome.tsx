
import React from 'react';
import { Link } from 'react-router-dom';
import { Cloud, CloudSun } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Welcome: React.FC = () => {
  return (
    <div className="min-h-screen bg-blue-gradient flex flex-col items-center justify-center px-4 py-12">
      <div className="animate-fade-in flex flex-col items-center">
        <div className="w-24 h-24 rounded-full bg-white flex items-center justify-center mb-6 shadow-lg">
          <CloudSun size={48} className="text-majira-blue" />
        </div>
        
        <h1 className="text-3xl font-bold text-white mb-2">Majira AI</h1>
        <p className="text-white text-opacity-90 text-center mb-8 max-w-xs">
          Precision weather forecasts tailored for agriculture
        </p>
        
        <div className="flex flex-col w-full gap-3 max-w-xs">
          <Button asChild className="bg-white text-majira-blue hover:bg-opacity-90 font-semibold py-6">
            <Link to="/login">Login</Link>
          </Button>
          
          <Button asChild variant="outline" className="bg-transparent text-white border-white hover:bg-white hover:bg-opacity-10 font-semibold py-6">
            <Link to="/register">Register</Link>
          </Button>
        </div>
        
        <div className="mt-16 text-white text-opacity-70 text-center text-sm">
          <p>Empowering farmers with weather intelligence</p>
          <p className="mt-2">© 2025 Majira AI</p>
        </div>
      </div>
      
      {/* Background elements */}
      <Cloud className="absolute top-24 left-12 text-white text-opacity-20" size={64} />
      <Cloud className="absolute bottom-32 right-12 text-white text-opacity-20" size={48} />
      <CloudSun className="absolute top-1/3 right-16 text-white text-opacity-20" size={56} />
    </div>
  );
};

export default Welcome;
