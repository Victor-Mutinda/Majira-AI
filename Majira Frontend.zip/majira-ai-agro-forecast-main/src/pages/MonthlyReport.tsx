
import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, Calendar, Droplets, Thermometer, Sun } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useWeather } from '@/contexts/WeatherContext';
import { getUvSeverity } from '@/components/Icons';
import LoadingSpinner from '@/components/LoadingSpinner';
import Navigation from '@/components/Navigation';

const MonthlyReport: React.FC = () => {
  const { weatherData, isLoading } = useWeather();

  if (isLoading) {
    return (
      <div className="app-container flex flex-col justify-center items-center">
        <LoadingSpinner size="large" />
        <p className="mt-4 text-white">Loading weather data...</p>
      </div>
    );
  }

  if (!weatherData) {
    return (
      <div className="app-container flex flex-col justify-center items-center">
        <p className="text-white">No weather data available</p>
      </div>
    );
  }

  const { monthlyReport } = weatherData;
  const uvSeverity = getUvSeverity(monthlyReport.averageUvIndex);
  
  // Calculate relative values for progress bars
  const tempPercentage = (monthlyReport.averageTemp / 40) * 100; // Assuming 40°C as max
  const precipPercentage = (monthlyReport.totalPrecipitation / 1000) * 100; // Assuming 1000 as max
  const uvPercentage = (monthlyReport.averageUvIndex / 12) * 100; // UV index max is 12
  
  // Generate monthly highlights
  const highlights = [
    {
      title: "Temperature Patterns",
      content: monthlyReport.averageTemp > 30 
        ? "Consistently high temperatures throughout the month may stress heat-sensitive crops."
        : monthlyReport.averageTemp > 25
          ? "Moderate temperatures are favorable for most crop varieties."
          : "Relatively cool temperatures may extend growing periods for some crops."
    },
    {
      title: "Rainfall Distribution",
      content: monthlyReport.totalPrecipitation > 700
        ? "Heavy precipitation has saturated soils. Monitor drainage in low-lying areas."
        : monthlyReport.totalPrecipitation > 400
          ? "Well-distributed rainfall has maintained good soil moisture levels."
          : "Lower than average rainfall. Consider supplemental irrigation strategies."
    },
    {
      title: "Solar Radiation",
      content: monthlyReport.averageUvIndex > 8
        ? "High UV levels throughout the month. Sun-sensitive crops may require protection."
        : monthlyReport.averageUvIndex > 5
          ? "Moderate UV levels are providing good photosynthetic activity."
          : "Lower UV levels. Monitor growth rates in light-demanding crops."
    }
  ];

  return (
    <div className="app-container">
      <div className="page-container pb-6">
        <div className="mb-6">
          <Link to="/reports" className="flex items-center text-white">
            <ChevronLeft size={20} />
            <span className="ml-1">Back to Reports</span>
          </Link>
        </div>
        
        <h1 className="text-2xl font-bold text-white mb-6">Monthly Weather Report</h1>
        
        <Card className="mb-6 animate-fade-in">
          <CardHeader className="pb-2">
            <div className="flex items-center">
              <Calendar className="mr-2 h-5 w-5 text-majira-blue" />
              <CardTitle>Monthly Overview</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Thermometer className="h-4 w-4 mr-2 text-majira-blue" />
                    <span className="text-sm font-medium">Average Temperature</span>
                  </div>
                  <span className="font-bold">{monthlyReport.averageTemp}°C</span>
                </div>
                <Progress value={tempPercentage} className="h-2" />
                <p className="text-xs text-gray-500 mt-1">
                  {monthlyReport.averageTemp > 30 
                    ? "Higher than seasonal average" 
                    : monthlyReport.averageTemp > 25 
                      ? "Within seasonal average" 
                      : "Lower than seasonal average"}
                </p>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Droplets className="h-4 w-4 mr-2 text-majira-blue" />
                    <span className="text-sm font-medium">Total Precipitation</span>
                  </div>
                  <span className="font-bold">{monthlyReport.totalPrecipitation}%</span>
                </div>
                <Progress value={precipPercentage} className="h-2" />
                <p className="text-xs text-gray-500 mt-1">
                  {monthlyReport.totalPrecipitation > 700 
                    ? "Above average rainfall" 
                    : monthlyReport.totalPrecipitation > 400 
                      ? "Normal rainfall levels" 
                      : "Below average rainfall"}
                </p>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Sun className="h-4 w-4 mr-2 text-majira-blue" />
                    <span className="text-sm font-medium">Average UV Index</span>
                  </div>
                  <span className={`font-bold ${uvSeverity.color}`}>
                    {monthlyReport.averageUvIndex} ({uvSeverity.level})
                  </span>
                </div>
                <Progress value={uvPercentage} className={`h-2 ${uvSeverity.color} opacity-80`} />
                <p className="text-xs text-gray-500 mt-1">
                  {uvSeverity.level === 'Extreme' || uvSeverity.level === 'Very High'
                    ? "Extreme UV protection recommended" 
                    : uvSeverity.level === 'High' 
                      ? "High UV protection recommended" 
                      : "Moderate UV protection recommended"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <div className="space-y-4 animate-fade-in" style={{ animationDelay: '0.1s' }}>
          <h2 className="text-xl font-bold text-white">Monthly Highlights</h2>
          
          {highlights.map((highlight, index) => (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">{highlight.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">{highlight.content}</p>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <Card className="mt-6 animate-fade-in" style={{ animationDelay: '0.2s' }}>
          <CardHeader>
            <CardTitle>Agricultural Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="font-medium">Irrigation Planning</h3>
                <p className="text-sm text-gray-700 mt-1">
                  {monthlyReport.totalPrecipitation > 700 
                    ? "Reduce irrigation frequency. Focus on maintaining proper drainage systems to prevent waterlogging." 
                    : monthlyReport.totalPrecipitation > 400 
                      ? "Maintain regular irrigation schedule, adjusting based on weekly precipitation forecasts." 
                      : "Increase irrigation frequency. Consider water conservation methods such as drip irrigation."}
                </p>
              </div>
              
              <div>
                <h3 className="font-medium">Crop Protection</h3>
                <p className="text-sm text-gray-700 mt-1">
                  {uvSeverity.level === 'Extreme' || uvSeverity.level === 'Very High'
                    ? "Install shade nets for sensitive crops. Schedule field work during early morning or late afternoon." 
                    : uvSeverity.level === 'High' 
                      ? "Monitor sun-sensitive crops. Consider row covers for protection during peak UV hours." 
                      : "Standard sun protection practices are adequate."}
                </p>
              </div>
              
              <div>
                <h3 className="font-medium">Disease Monitoring</h3>
                <p className="text-sm text-gray-700 mt-1">
                  {monthlyReport.totalPrecipitation > 700 && monthlyReport.averageTemp > 25
                    ? "High risk of fungal diseases due to warm, wet conditions. Implement preventative fungicide program." 
                    : monthlyReport.totalPrecipitation > 400 && monthlyReport.averageTemp > 25
                      ? "Moderate disease risk. Monitor crops regularly and apply fungicides as needed." 
                      : "Lower disease pressure expected. Continue routine monitoring."}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Navigation />
    </div>
  );
};

export default MonthlyReport;
