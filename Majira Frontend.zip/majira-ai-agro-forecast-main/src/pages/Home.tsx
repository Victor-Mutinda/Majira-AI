
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  MapPin, 
  Droplets, 
  Wind, 
  RefreshCw 
} from 'lucide-react';
import { useWeather } from '@/contexts/WeatherContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { 
  getWeatherIcon, 
  getUvSeverity 
} from '@/components/Icons';
import WeatherCard from '@/components/WeatherCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import Navigation from '@/components/Navigation';

const Home: React.FC = () => {
  const { weatherData, isLoading, refreshWeather } = useWeather();
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = async () => {
    setRefreshing(true);
    await refreshWeather();
    setRefreshing(false);
  };

  if (isLoading) {
    return (
      <div className="app-container flex flex-col justify-center items-center">
        <LoadingSpinner size="large" />
        <p className="mt-4 text-white">Loading weather data...</p>
      </div>
    );
  }

  if (!weatherData) {
    return (
      <div className="app-container flex flex-col justify-center items-center">
        <p className="text-white">No weather data available</p>
        <Button onClick={refreshWeather} className="mt-4">
          Try Again
        </Button>
      </div>
    );
  }

  const { currentWeather, location, dailyForecast } = weatherData;
  const uvSeverity = getUvSeverity(currentWeather.uvIndex);

  return (
    <div className="app-container">
      <div className="page-container">
        {/* Header section */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center">
            <MapPin className="text-white mr-1" size={20} />
            <h1 className="text-xl font-bold text-white">{location}</h1>
          </div>
          <Button 
            variant="outline" 
            size="icon" 
            className="rounded-full border-white text-white hover:bg-white hover:bg-opacity-20"
            onClick={handleRefresh}
            disabled={refreshing}
          >
            {refreshing ? <LoadingSpinner size="small" /> : <RefreshCw size={18} />}
          </Button>
        </div>
        
        {/* Current weather */}
        <div className="glass-card p-6 mb-6 animate-fade-in">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-4xl font-bold">{currentWeather.temperature}°C</h2>
              <p className="text-gray-600 capitalize">{currentWeather.condition}</p>
            </div>
            <div className="text-majira-blue">
              {getWeatherIcon(currentWeather.condition, { size: 64 })}
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-4 mt-6">
            <div className="text-center">
              <Droplets className="mx-auto text-majira-blue mb-1" size={20} />
              <p className="text-xs text-gray-600">Humidity</p>
              <p className="font-medium">{currentWeather.humidity}%</p>
            </div>
            <div className="text-center">
              <Wind className="mx-auto text-majira-blue mb-1" size={20} />
              <p className="text-xs text-gray-600">Wind</p>
              <p className="font-medium">{currentWeather.wind} km/h</p>
            </div>
            <div className="text-center">
              <div className={`mx-auto mb-1 ${uvSeverity.color}`}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="mx-auto">
                  <circle cx="12" cy="12" r="6" stroke="currentColor" strokeWidth="2" />
                  <path d="M12 2V4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  <path d="M12 20V22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  <path d="M4 12H2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  <path d="M22 12H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  <path d="M19.7782 4.22266L17.5563 6.44455" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  <path d="M6.44342 17.5576L4.22153 19.7795" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  <path d="M19.7782 19.7773L17.5563 17.5554" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  <path d="M6.44342 6.44232L4.22153 4.22043" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </div>
              <p className="text-xs text-gray-600">UV Index</p>
              <p className={`font-medium ${uvSeverity.color}`}>{uvSeverity.level}</p>
            </div>
          </div>
        </div>
        
        {/* Forecast tabs */}
        <div className="mb-6 animate-fade-in" style={{ animationDelay: '0.1s' }}>
          <Tabs defaultValue="today">
            <TabsList className="w-full grid grid-cols-3 mb-4">
              <TabsTrigger value="today">Today</TabsTrigger>
              <TabsTrigger value="week">7 Days</TabsTrigger>
              <TabsTrigger value="monthly">
                <Link to="/reports/monthly">Monthly</Link>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="today" className="m-0">
              <div className="overflow-x-auto pb-4">
                <div className="flex gap-3">
                  {dailyForecast.slice(0, 1).map((day, index) => (
                    <WeatherCard
                      key={index}
                      day={day.day}
                      date={day.date.split('-').slice(1).join('/')}
                      condition={day.condition}
                      highTemp={day.temperature.high}
                      lowTemp={day.temperature.low}
                      metrics={[
                        { type: 'precipitation', value: day.precipitation },
                        { type: 'wind', value: day.wind },
                        { type: 'uvIndex', value: day.uvIndex },
                        { type: 'humidity', value: day.humidity }
                      ]}
                    />
                  ))}
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="week" className="m-0">
              <div className="overflow-x-auto pb-4">
                <div className="flex gap-3">
                  {dailyForecast.map((day, index) => (
                    <WeatherCard
                      key={index}
                      day={day.day}
                      date={day.date.split('-').slice(1).join('/')}
                      condition={day.condition}
                      highTemp={day.temperature.high}
                      lowTemp={day.temperature.low}
                      compact
                    />
                  ))}
                </div>
              </div>
              <div className="mt-4">
                <Button asChild className="w-full">
                  <Link to="/reports/weekly">View Detailed Report</Link>
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="monthly" className="m-0">
              <div className="glass-card p-4 text-center">
                <h3 className="font-medium mb-2">Monthly Summary</h3>
                <p className="text-sm text-gray-600 mb-3">
                  View comprehensive monthly weather data and agricultural insights
                </p>
                <Button asChild className="w-full">
                  <Link to="/reports/monthly">View Monthly Report</Link>
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
        
        {/* Agricultural insights */}
        <div className="glass-card p-5 animate-fade-in" style={{ animationDelay: '0.2s' }}>
          <h3 className="font-semibold mb-3">Agricultural Insights</h3>
          <div className="text-sm text-gray-700">
            <p className="mb-2">
              <span className="font-medium">Today's Recommendation:</span> {' '}
              {currentWeather.precipitation > 60 
                ? 'Delay irrigation. Natural rainfall expected.' 
                : currentWeather.precipitation > 30 
                  ? 'Light irrigation recommended for seedlings.' 
                  : 'Regular irrigation advised due to dry conditions.'}
            </p>
            <p className="mb-2">
              <span className="font-medium">UV Alert:</span> {' '}
              {uvSeverity.level === 'Extreme' || uvSeverity.level === 'Very High'
                ? 'Provide shade for sensitive crops and avoid midday field work.'
                : uvSeverity.level === 'High'
                  ? 'Consider protection for UV-sensitive crops.'
                  : 'Normal UV levels, standard practices advised.'}
            </p>
            <Button variant="link" asChild className="p-0 h-auto text-majira-blue">
              <Link to="/reports">View Full Agricultural Report</Link>
            </Button>
          </div>
        </div>
      </div>
      
      <Navigation />
    </div>
  );
};

export default Home;
