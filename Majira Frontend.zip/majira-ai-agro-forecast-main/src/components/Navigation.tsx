
import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, BarChart3, User } from 'lucide-react';

const Navigation: React.FC = () => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white shadow-lg z-50">
      <div className="container mx-auto">
        <div className="flex justify-around items-center h-16">
          <NavLink 
            to="/" 
            className={({ isActive }) => 
              `flex flex-col items-center justify-center w-1/3 py-2 ${isActive ? 'text-majira-blue' : 'text-gray-500'}`
            }
            end
          >
            <Home size={24} />
            <span className="text-xs mt-1">Home</span>
          </NavLink>
          <NavLink 
            to="/reports" 
            className={({ isActive }) => 
              `flex flex-col items-center justify-center w-1/3 py-2 ${isActive ? 'text-majira-blue' : 'text-gray-500'}`
            }
          >
            <BarChart3 size={24} />
            <span className="text-xs mt-1">Reports</span>
          </NavLink>
          <NavLink 
            to="/profile" 
            className={({ isActive }) => 
              `flex flex-col items-center justify-center w-1/3 py-2 ${isActive ? 'text-majira-blue' : 'text-gray-500'}`
            }
          >
            <User size={24} />
            <span className="text-xs mt-1">Profile</span>
          </NavLink>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
