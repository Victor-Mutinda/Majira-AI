
import React from 'react';
import { getWeatherIcon, getMetricIcon, formatWeatherValue } from './Icons';

type WeatherCardProps = {
  day: string;
  date?: string;
  condition: string;
  highTemp: number;
  lowTemp: number;
  metrics?: Array<{
    type: string;
    value: number;
  }>;
  compact?: boolean;
};

const WeatherCard: React.FC<WeatherCardProps> = ({
  day,
  date,
  condition,
  highTemp,
  lowTemp,
  metrics = [],
  compact = false
}) => {
  return (
    <div className={`weather-card ${compact ? 'min-w-[100px]' : 'min-w-[140px]'}`}>
      <div className="text-lg font-medium">{day}</div>
      {date && <div className="text-xs text-gray-500">{date}</div>}
      <div className="my-2">
        {getWeatherIcon(condition, { size: compact ? 32 : 40, className: 'text-majira-blue' })}
      </div>
      <div className="flex gap-2 font-semibold">
        <span>{highTemp}°</span>
        <span className="text-gray-400">{lowTemp}°</span>
      </div>
      
      {!compact && metrics && metrics.length > 0 && (
        <div className="mt-2 w-full space-y-2">
          {metrics.map((metric, idx) => (
            <div key={idx} className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1">
                {getMetricIcon(metric.type, { size: 14 })}
                <span className="capitalize">{metric.type}</span>
              </div>
              <span>{formatWeatherValue(metric.value, metric.type)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default WeatherCard;
