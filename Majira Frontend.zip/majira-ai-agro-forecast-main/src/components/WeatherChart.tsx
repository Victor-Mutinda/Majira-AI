
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

type ChartData = {
  name: string;
  value: number;
  color?: string;
}

type WeatherChartProps = {
  data: ChartData[];
  dataKey: string;
  label: string;
  unit: string;
  color?: string;
  height?: number;
}

const WeatherChart: React.FC<WeatherChartProps> = ({ 
  data, 
  dataKey, 
  label, 
  unit, 
  color = "#1E88E5",
  height = 200
}) => {
  return (
    <div className="w-full">
      <h3 className="text-lg font-medium mb-2">{label}</h3>
      <div style={{ width: '100%', height }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            margin={{
              top: 5,
              right: 5,
              left: 5,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="name" tick={{ fontSize: 12 }} />
            <YAxis unit={unit} tick={{ fontSize: 12 }} width={40} />
            <Tooltip
              formatter={(value: number) => [`${value}${unit}`, label]}
              contentStyle={{ borderRadius: '8px' }}
            />
            <Bar 
              dataKey={dataKey} 
              fill={color} 
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default WeatherChart;
