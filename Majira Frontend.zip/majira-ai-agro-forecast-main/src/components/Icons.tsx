
import React from 'react';
import { 
  Sun, 
  CloudSun, 
  Cloud, 
  CloudRain, 
  CloudLightning,
  Droplets,
  Wind,
  Thermometer,
  BarChart,
  LucideProps
} from 'lucide-react';

// Get weather condition icon based on condition string
export const getWeatherIcon = (condition: string, props?: LucideProps) => {
  switch (condition) {
    case 'sunny':
      return <Sun {...props} />;
    case 'partly-cloudy':
      return <CloudSun {...props} />;
    case 'cloudy':
      return <Cloud {...props} />;
    case 'rainy':
      return <CloudRain {...props} />;
    case 'stormy':
      return <CloudLightning {...props} />;
    default:
      return <Sun {...props} />;
  }
};

// Get weather metric icon based on metric type
export const getMetricIcon = (metric: string, props?: LucideProps) => {
  switch (metric) {
    case 'humidity':
    case 'precipitation':
      return <Droplets {...props} />;
    case 'wind':
      return <Wind {...props} />;
    case 'temperature':
      return <Thermometer {...props} />;
    case 'uvIndex':
      return <Sun {...props} />;
    default:
      return <BarChart {...props} />;
  }
};

// Format weather values with appropriate units
export const formatWeatherValue = (value: number, metric: string) => {
  switch (metric) {
    case 'temperature':
      return `${value}°C`;
    case 'humidity':
      return `${value}%`;
    case 'precipitation':
      return `${value}%`;
    case 'wind':
      return `${value} km/h`;
    case 'uvIndex':
      return value.toString();
    default:
      return value.toString();
  }
};

// Get severity level based on UV index
export const getUvSeverity = (uvIndex: number) => {
  if (uvIndex <= 2) return { level: 'Low', color: 'text-green-500' };
  if (uvIndex <= 5) return { level: 'Moderate', color: 'text-yellow-500' };
  if (uvIndex <= 7) return { level: 'High', color: 'text-orange-500' };
  if (uvIndex <= 10) return { level: 'Very High', color: 'text-red-500' };
  return { level: 'Extreme', color: 'text-purple-500' };
};
