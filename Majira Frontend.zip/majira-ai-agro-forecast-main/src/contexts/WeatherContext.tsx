
import React, { createContext, useContext, useState, useEffect } from 'react';

// Define types for weather data
type WeatherCondition = 'sunny' | 'partly-cloudy' | 'cloudy' | 'rainy' | 'stormy';

type DailyForecast = {
  date: string;
  day: string;
  temperature: {
    high: number;
    low: number;
    current?: number;
  };
  condition: WeatherCondition;
  precipitation: number;
  humidity: number;
  wind: number;
  uvIndex: number;
};

type WeatherData = {
  location: string;
  currentWeather: {
    temperature: number;
    condition: WeatherCondition;
    humidity: number;
    wind: number;
    uvIndex: number;
    precipitation: number;
  };
  dailyForecast: DailyForecast[];
  weeklyForecast: DailyForecast[];
  monthlyReport: {
    averageTemp: number;
    totalPrecipitation: number;
    averageUvIndex: number;
  };
};

type WeatherContextType = {
  weatherData: WeatherData | null;
  isLoading: boolean;
  error: string | null;
  refreshWeather: () => void;
};

// Create the weather context
const WeatherContext = createContext<WeatherContextType | undefined>(undefined);

// Mock weather data
const generateMockWeatherData = (): WeatherData => {
  const conditions: WeatherCondition[] = ['sunny', 'partly-cloudy', 'cloudy', 'rainy', 'stormy'];
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  const currentDate = new Date();
  const dailyForecast: DailyForecast[] = [];
  const weeklyForecast: DailyForecast[] = [];
  
  // Generate daily forecast for next 7 days
  for (let i = 0; i < 7; i++) {
    const forecastDate = new Date();
    forecastDate.setDate(currentDate.getDate() + i);
    
    const dayTemp = Math.floor(Math.random() * 10) + 25; // 25-35°C
    const dailyData: DailyForecast = {
      date: forecastDate.toISOString().split('T')[0],
      day: days[forecastDate.getDay()],
      temperature: {
        high: dayTemp,
        low: dayTemp - Math.floor(Math.random() * 8) - 2, // 5-10°C lower than high
        current: i === 0 ? dayTemp - Math.floor(Math.random() * 3) : undefined
      },
      condition: conditions[Math.floor(Math.random() * conditions.length)],
      precipitation: Math.floor(Math.random() * 100),
      humidity: Math.floor(Math.random() * 30) + 50, // 50-80%
      wind: Math.floor(Math.random() * 20) + 5, // 5-25 km/h
      uvIndex: Math.floor(Math.random() * 12) + 1 // 1-12
    };
    
    dailyForecast.push(dailyData);
    weeklyForecast.push(dailyData);
  }

  return {
    location: 'Machakos',
    currentWeather: {
      temperature: dailyForecast[0].temperature.current!,
      condition: dailyForecast[0].condition,
      humidity: dailyForecast[0].humidity,
      wind: dailyForecast[0].wind,
      uvIndex: dailyForecast[0].uvIndex,
      precipitation: dailyForecast[0].precipitation
    },
    dailyForecast,
    weeklyForecast,
    monthlyReport: {
      averageTemp: Math.floor(dailyForecast.reduce((sum, day) => sum + day.temperature.high, 0) / dailyForecast.length),
      totalPrecipitation: dailyForecast.reduce((sum, day) => sum + day.precipitation, 0),
      averageUvIndex: Math.floor(dailyForecast.reduce((sum, day) => sum + day.uvIndex, 0) / dailyForecast.length)
    }
  };
};

export const WeatherProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchWeatherData = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      const mockData = generateMockWeatherData();
      setWeatherData(mockData);
    } catch (err) {
      setError('Failed to fetch weather data. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch weather data on component mount
  useEffect(() => {
    fetchWeatherData();
  }, []);

  const value = {
    weatherData,
    isLoading,
    error,
    refreshWeather: fetchWeatherData
  };

  return <WeatherContext.Provider value={value}>{children}</WeatherContext.Provider>;
};

// Custom hook to use the weather context
export const useWeather = () => {
  const context = useContext(WeatherContext);
  if (context === undefined) {
    throw new Error('useWeather must be used within a WeatherProvider');
  }
  return context;
};
